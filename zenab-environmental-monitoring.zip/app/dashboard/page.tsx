import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { AirQualityCard } from "@/components/dashboard/air-quality-card"
import { AQIChart } from "@/components/dashboard/aqi-chart"
import { PollutionOverview } from "@/components/dashboard/pollution-overview"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RefreshCw, MapPin, TrendingUp, AlertCircle, FileText, Brain } from "lucide-react"
import Link from "next/link"

export default async function DashboardPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Fetch recent air quality data
  const { data: airQualityData } = await supabase
    .from("air_quality_data")
    .select("*")
    .order("timestamp", { ascending: false })
    .limit(12)

  // Generate chart data (simulated real-time data)
  const chartData = Array.from({ length: 24 }, (_, i) => ({
    time: `${23 - i}:00`,
    aqi: Math.floor(Math.random() * 100) + 50,
    city: "Delhi",
  })).reverse()

  // Calculate overview statistics
  const totalStations = airQualityData?.length || 0
  const goodQuality =
    airQualityData?.filter((d) => d.pollution_level === "Good" || d.pollution_level === "Moderate").length || 0
  const moderateQuality =
    airQualityData?.filter((d) => d.pollution_level === "Unhealthy for Sensitive Groups").length || 0
  const unhealthyQuality =
    airQualityData?.filter(
      (d) =>
        d.pollution_level === "Unhealthy" ||
        d.pollution_level === "Very Unhealthy" ||
        d.pollution_level === "Hazardous",
    ).length || 0
  const averageAQI = Math.round((airQualityData?.reduce((sum, d) => sum + d.aqi, 0) || 0) / totalStations) || 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5">
      <DashboardHeader userEmail={data.user.email} />

      <main className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Environmental Dashboard</h1>
            <p className="text-muted-foreground">Real-time air quality monitoring across India</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
              <RefreshCw className="h-4 w-4" />
              <span>Refresh</span>
            </Button>
            <Button asChild size="sm" className="flex items-center space-x-2">
              <Link href="/map">
                <MapPin className="h-4 w-4" />
                <span>View Map</span>
              </Link>
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">National Average AQI</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{averageAQI}</div>
              <p className="text-xs text-muted-foreground">+2.1% from yesterday</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monitoring Stations</CardTitle>
              <MapPin className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalStations}</div>
              <p className="text-xs text-muted-foreground">Active stations</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Unhealthy Areas</CardTitle>
              <AlertCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{unhealthyQuality}</div>
              <p className="text-xs text-muted-foreground">Require attention</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Good Quality Areas</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{goodQuality}</div>
              <p className="text-xs text-muted-foreground">Safe for all groups</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts and Overview */}
        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <AQIChart data={chartData} />
          </div>
          <PollutionOverview
            totalStations={totalStations}
            goodQuality={goodQuality}
            moderateQuality={moderateQuality}
            unhealthyQuality={unhealthyQuality}
            averageAQI={averageAQI}
          />
        </div>

        {/* Air Quality Cards */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Live Air Quality Data</h2>
            <Button asChild variant="outline">
              <Link href="/map">View All Locations</Link>
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {airQualityData?.map((station) => (
              <AirQualityCard
                key={station.id}
                location={`${station.location}, ${station.city}`}
                aqi={station.aqi}
                pollutionLevel={station.pollution_level}
                pm25={station.pm25}
                pm10={station.pm10}
                no2={station.no2}
                timestamp={station.timestamp}
              />
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Access key features and tools</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <Button asChild variant="outline" className="h-20 flex flex-col space-y-2 bg-transparent">
                <Link href="/health">
                  <AlertCircle className="h-6 w-6" />
                  <span>Health Assessment</span>
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex flex-col space-y-2 bg-transparent">
                <Link href="/reports">
                  <FileText className="h-6 w-6" />
                  <span>Generate Report</span>
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex flex-col space-y-2 bg-transparent">
                <Link href="/map">
                  <MapPin className="h-6 w-6" />
                  <span>Interactive Map</span>
                </Link>
              </Button>
              <Button asChild variant="outline" className="h-20 flex flex-col space-y-2 bg-transparent">
                <Link href="/ai-insights">
                  <Brain className="h-6 w-6" />
                  <span>AI Insights</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
