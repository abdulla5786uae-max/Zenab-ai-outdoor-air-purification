"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { HealthAssessmentForm } from "@/components/health/health-assessment-form"
import { HealthAssessmentResults } from "@/components/health/health-assessment-results"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { HealthAssessor } from "@/lib/health/health-assessor"
import type { HealthProfile, HealthAssessment } from "@/lib/health/health-assessor"
import { Heart, Shield, Activity, Users } from "lucide-react"

export default function HealthPage() {
  const [assessment, setAssessment] = useState<HealthAssessment | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  // Mock user email - in real app, get from auth
  const userEmail = "user@example.com"

  const handleAssessment = async (profile: HealthProfile) => {
    setIsLoading(true)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Mock air quality data - in real app, fetch based on location
      const mockAirQuality = {
        aqi: 156,
        pm25: 84.7,
        pm10: 138.9,
        no2: 46.2,
        so2: 13.1,
        co: 1.5,
        o3: 72.3,
        pollutionLevel: "Unhealthy",
      }

      const result = HealthAssessor.assessHealth(profile, mockAirQuality)
      setAssessment(result)
    } catch (error) {
      console.error("Assessment error:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleNewAssessment = () => {
    setAssessment(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5">
      <DashboardHeader userEmail={userEmail} />

      <main className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Health Assessment</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get personalized health recommendations based on current air quality conditions and your individual health
            profile
          </p>
        </div>

        {!assessment ? (
          <>
            {/* Info Cards */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardHeader className="text-center">
                  <Heart className="h-8 w-8 text-primary mx-auto mb-2" />
                  <CardTitle className="text-lg">Personalized</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    Tailored recommendations based on your unique health profile
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <Shield className="h-8 w-8 text-primary mx-auto mb-2" />
                  <CardTitle className="text-lg">Risk Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    Comprehensive risk assessment for air quality exposure
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <Activity className="h-8 w-8 text-primary mx-auto mb-2" />
                  <CardTitle className="text-lg">Action Plans</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    Immediate and long-term strategies to protect your health
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="text-center">
                  <Users className="h-8 w-8 text-primary mx-auto mb-2" />
                  <CardTitle className="text-lg">Expert Backed</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground text-center">
                    Recommendations based on medical research and guidelines
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Assessment Form */}
            <HealthAssessmentForm onSubmit={handleAssessment} isLoading={isLoading} />
          </>
        ) : (
          <HealthAssessmentResults assessment={assessment} onNewAssessment={handleNewAssessment} />
        )}
      </main>
    </div>
  )
}
