import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { AIInsightsCard } from "@/components/ai/ai-insights-card"
import { PollutionTrendsChart } from "@/components/ai/pollution-trends-chart"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PollutionClassifier } from "@/lib/ai/pollution-classifier"
import { Brain, Zap, Target, TrendingUp } from "lucide-react"

export default async function AIInsightsPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Fetch recent air quality data for AI analysis
  const { data: airQualityData } = await supabase
    .from("air_quality_data")
    .select("*")
    .order("timestamp", { ascending: false })
    .limit(5)

  // Generate AI insights for top locations
  const aiInsights =
    airQualityData?.map((station) => {
      const pollutionData = {
        pm25: station.pm25,
        pm10: station.pm10,
        no2: station.no2,
        so2: station.so2,
        co: station.co,
        o3: station.o3,
      }

      return {
        location: `${station.location}, ${station.city}`,
        insights: PollutionClassifier.classifyPollution(pollutionData),
        station,
      }
    }) || []

  // Generate sample trend data for charts
  const generateTrendData = () => {
    return Array.from({ length: 24 }, (_, i) => {
      const hour = i
      const actual = Math.floor(Math.random() * 100) + 50
      const predicted = actual + (Math.random() * 20 - 10)
      return {
        time: `${hour.toString().padStart(2, "0")}:00`,
        actual,
        predicted: Math.max(0, Math.round(predicted)),
        confidence: Math.floor(Math.random() * 20) + 80,
      }
    })
  }

  const trendData = generateTrendData()

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5">
      <DashboardHeader userEmail={data.user.email} />

      <main className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">AI Pollution Insights</h1>
            <p className="text-muted-foreground">Advanced AI analysis and predictions for environmental monitoring</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
              <Zap className="h-4 w-4" />
              <span>Auto-Refresh</span>
            </Button>
            <Button size="sm" className="flex items-center space-x-2">
              <Target className="h-4 w-4" />
              <span>Calibrate AI</span>
            </Button>
          </div>
        </div>

        {/* AI Overview Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">AI Accuracy</CardTitle>
              <Brain className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">94.2%</div>
              <p className="text-xs text-muted-foreground">+2.1% from last week</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Predictions Made</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12,847</div>
              <p className="text-xs text-muted-foreground">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">High Risk Alerts</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">23</div>
              <p className="text-xs text-muted-foreground">Active warnings</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Model Updates</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">v2.1</div>
              <p className="text-xs text-muted-foreground">Latest version</p>
            </CardContent>
          </Card>
        </div>

        {/* Trends Chart */}
        <div className="mb-8">
          <PollutionTrendsChart data={trendData} pollutant="PM2.5" />
        </div>

        {/* AI Insights Grid */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-foreground">Location-Based AI Analysis</h2>
            <Button variant="outline" className="bg-transparent">
              View All Insights
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {aiInsights.slice(0, 6).map((insight, index) => (
              <AIInsightsCard key={index} insights={insight.insights} location={insight.location} />
            ))}
          </div>
        </div>

        {/* AI Model Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-primary" />
              <span>AI Model Information</span>
            </CardTitle>
            <CardDescription>Details about our pollution classification and prediction models</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-semibold">Classification Model</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Algorithm</span>
                    <span>Advanced AQI Calculator</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Training Data</span>
                    <span>2M+ data points</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Accuracy</span>
                    <span>94.2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Updated</span>
                    <span>2 days ago</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-semibold">Prediction Model</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Forecast Range</span>
                    <span>1-24 hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Factors Considered</span>
                    <span>Weather, Traffic, Seasonal</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Update Frequency</span>
                    <span>Every 15 minutes</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Confidence Level</span>
                    <span>87-95%</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
