import { type NextRequest, NextResponse } from "next/server"
import { PollutionClassifier } from "@/lib/ai/pollution-classifier"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // Validate input data
    const requiredFields = ["pm25", "pm10", "no2", "so2", "co", "o3"]
    for (const field of requiredFields) {
      if (typeof data[field] !== "number") {
        return NextResponse.json({ error: `Missing or invalid ${field} value` }, { status: 400 })
      }
    }

    // Classify pollution using AI
    const classification = PollutionClassifier.classifyPollution(data)

    return NextResponse.json({
      success: true,
      data: classification,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("AI Classification Error:", error)
    return NextResponse.json({ error: "Failed to classify pollution data" }, { status: 500 })
  }
}
