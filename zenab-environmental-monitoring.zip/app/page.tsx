import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Wind, MapPin, Activity, FileText, Shield, Smartphone } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Wind className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold text-foreground">Zenab</span>
          </div>
          <div className="flex items-center space-x-4">
            <Button asChild variant="ghost">
              <Link href="/auth/login">Sign In</Link>
            </Button>
            <Button asChild>
              <Link href="/auth/signup">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl font-bold text-foreground mb-6 text-balance">
            Monitor Air Quality in Real-Time Across India
          </h1>
          <p className="text-xl text-muted-foreground mb-8 text-pretty">
            Zenab provides comprehensive environmental monitoring with AI-powered insights, health assessments, and
            interactive pollution mapping to help you make informed decisions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="text-lg px-8">
              <Link href="/auth/signup">Start Monitoring</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8 bg-transparent">
              <Link href="/dashboard">View Demo</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-foreground mb-4">Comprehensive Environmental Monitoring</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to understand and respond to air quality challenges in your area
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardHeader>
              <MapPin className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Interactive India Map</CardTitle>
              <CardDescription>
                Explore pollution levels across different zones with real-time data visualization
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardHeader>
              <Activity className="h-12 w-12 text-primary mb-4" />
              <CardTitle>AI-Powered Classification</CardTitle>
              <CardDescription>
                Advanced algorithms classify pollution levels and predict health impacts
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardHeader>
              <Shield className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Health Assessments</CardTitle>
              <CardDescription>
                Personalized health risk evaluations based on your location and conditions
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardHeader>
              <FileText className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Detailed Reports</CardTitle>
              <CardDescription>
                Generate comprehensive environmental reports for personal or professional use
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardHeader>
              <Wind className="h-12 w-12 text-primary mb-4" />
              <CardTitle>Real-Time Data</CardTitle>
              <CardDescription>
                Access live air quality measurements from monitoring stations across India
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardHeader>
              <Smartphone className="h-12 w-12 text-primary mb-4" />
              <CardTitle>PWA Ready</CardTitle>
              <CardDescription>Install as a mobile app for offline access and push notifications</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="bg-primary text-primary-foreground">
          <CardContent className="p-12 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Start Monitoring?</h2>
            <p className="text-lg mb-8 opacity-90">
              Join thousands of users who trust Zenab for environmental monitoring
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg px-8">
              <Link href="/auth/signup">Create Your Account</Link>
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Wind className="h-6 w-6 text-primary" />
              <span className="font-semibold text-foreground">Zenab</span>
            </div>
            <p className="text-sm text-muted-foreground">© 2024 Zenab Environmental Monitoring. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
