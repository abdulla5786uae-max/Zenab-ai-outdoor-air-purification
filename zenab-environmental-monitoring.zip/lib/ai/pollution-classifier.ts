// AI-powered pollution classification and prediction system
export interface PollutionData {
  pm25: number
  pm10: number
  no2: number
  so2: number
  co: number
  o3: number
  temperature?: number
  humidity?: number
  windSpeed?: number
}

export interface ClassificationResult {
  aqi: number
  pollutionLevel: string
  healthRisk: string
  recommendations: string[]
  prediction: {
    nextHour: number
    next6Hours: number
    next24Hours: number
  }
  dominantPollutant: string
  confidence: number
}

export class PollutionClassifier {
  // Calculate AQI based on pollutant concentrations
  static calculateAQI(data: PollutionData): number {
    const pm25AQI = this.calculatePM25AQI(data.pm25)
    const pm10AQI = this.calculatePM10AQI(data.pm10)
    const no2AQI = this.calculateNO2AQI(data.no2)
    const so2AQI = this.calculateSO2AQI(data.so2)
    const coAQI = this.calculateCOAQI(data.co)
    const o3AQI = this.calculateO3AQI(data.o3)

    return Math.max(pm25AQI, pm10AQI, no2AQI, so2AQI, coAQI, o3AQI)
  }

  // PM2.5 AQI calculation
  private static calculatePM25AQI(pm25: number): number {
    if (pm25 <= 12) return this.linearInterpolation(pm25, 0, 12, 0, 50)
    if (pm25 <= 35.4) return this.linearInterpolation(pm25, 12.1, 35.4, 51, 100)
    if (pm25 <= 55.4) return this.linearInterpolation(pm25, 35.5, 55.4, 101, 150)
    if (pm25 <= 150.4) return this.linearInterpolation(pm25, 55.5, 150.4, 151, 200)
    if (pm25 <= 250.4) return this.linearInterpolation(pm25, 150.5, 250.4, 201, 300)
    return this.linearInterpolation(pm25, 250.5, 350.4, 301, 400)
  }

  // PM10 AQI calculation
  private static calculatePM10AQI(pm10: number): number {
    if (pm10 <= 54) return this.linearInterpolation(pm10, 0, 54, 0, 50)
    if (pm10 <= 154) return this.linearInterpolation(pm10, 55, 154, 51, 100)
    if (pm10 <= 254) return this.linearInterpolation(pm10, 155, 254, 101, 150)
    if (pm10 <= 354) return this.linearInterpolation(pm10, 255, 354, 151, 200)
    if (pm10 <= 424) return this.linearInterpolation(pm10, 355, 424, 201, 300)
    return this.linearInterpolation(pm10, 425, 504, 301, 400)
  }

  // NO2 AQI calculation
  private static calculateNO2AQI(no2: number): number {
    if (no2 <= 53) return this.linearInterpolation(no2, 0, 53, 0, 50)
    if (no2 <= 100) return this.linearInterpolation(no2, 54, 100, 51, 100)
    if (no2 <= 360) return this.linearInterpolation(no2, 101, 360, 101, 150)
    if (no2 <= 649) return this.linearInterpolation(no2, 361, 649, 151, 200)
    if (no2 <= 1249) return this.linearInterpolation(no2, 650, 1249, 201, 300)
    return this.linearInterpolation(no2, 1250, 1649, 301, 400)
  }

  // SO2 AQI calculation
  private static calculateSO2AQI(so2: number): number {
    if (so2 <= 35) return this.linearInterpolation(so2, 0, 35, 0, 50)
    if (so2 <= 75) return this.linearInterpolation(so2, 36, 75, 51, 100)
    if (so2 <= 185) return this.linearInterpolation(so2, 76, 185, 101, 150)
    if (so2 <= 304) return this.linearInterpolation(so2, 186, 304, 151, 200)
    if (so2 <= 604) return this.linearInterpolation(so2, 305, 604, 201, 300)
    return this.linearInterpolation(so2, 605, 804, 301, 400)
  }

  // CO AQI calculation
  private static calculateCOAQI(co: number): number {
    if (co <= 4.4) return this.linearInterpolation(co, 0, 4.4, 0, 50)
    if (co <= 9.4) return this.linearInterpolation(co, 4.5, 9.4, 51, 100)
    if (co <= 12.4) return this.linearInterpolation(co, 9.5, 12.4, 101, 150)
    if (co <= 15.4) return this.linearInterpolation(co, 12.5, 15.4, 151, 200)
    if (co <= 30.4) return this.linearInterpolation(co, 15.5, 30.4, 201, 300)
    return this.linearInterpolation(co, 30.5, 40.4, 301, 400)
  }

  // O3 AQI calculation
  private static calculateO3AQI(o3: number): number {
    if (o3 <= 54) return this.linearInterpolation(o3, 0, 54, 0, 50)
    if (o3 <= 70) return this.linearInterpolation(o3, 55, 70, 51, 100)
    if (o3 <= 85) return this.linearInterpolation(o3, 71, 85, 101, 150)
    if (o3 <= 105) return this.linearInterpolation(o3, 86, 105, 151, 200)
    if (o3 <= 200) return this.linearInterpolation(o3, 106, 200, 201, 300)
    return this.linearInterpolation(o3, 201, 300, 301, 400)
  }

  // Linear interpolation helper
  private static linearInterpolation(value: number, x1: number, x2: number, y1: number, y2: number): number {
    return Math.round(((y2 - y1) / (x2 - x1)) * (value - x1) + y1)
  }

  // Get pollution level from AQI
  static getPollutionLevel(aqi: number): string {
    if (aqi <= 50) return "Good"
    if (aqi <= 100) return "Moderate"
    if (aqi <= 150) return "Unhealthy for Sensitive Groups"
    if (aqi <= 200) return "Unhealthy"
    if (aqi <= 300) return "Very Unhealthy"
    return "Hazardous"
  }

  // Get health risk assessment
  static getHealthRisk(aqi: number): string {
    if (aqi <= 50) return "Low"
    if (aqi <= 100) return "Moderate"
    if (aqi <= 150) return "High for Sensitive Groups"
    if (aqi <= 200) return "High"
    if (aqi <= 300) return "Very High"
    return "Emergency"
  }

  // Get dominant pollutant
  static getDominantPollutant(data: PollutionData): string {
    const pollutants = {
      PM25: this.calculatePM25AQI(data.pm25),
      PM10: this.calculatePM10AQI(data.pm10),
      NO2: this.calculateNO2AQI(data.no2),
      SO2: this.calculateSO2AQI(data.so2),
      CO: this.calculateCOAQI(data.co),
      O3: this.calculateO3AQI(data.o3),
    }

    return Object.entries(pollutants).reduce((a, b) => (pollutants[a[0]] > pollutants[b[0]] ? a : b))[0]
  }

  // Generate AI-powered recommendations
  static generateRecommendations(data: PollutionData, aqi: number): string[] {
    const recommendations: string[] = []
    const level = this.getPollutionLevel(aqi)

    // Base recommendations by pollution level
    switch (level) {
      case "Good":
        recommendations.push("Air quality is satisfactory. Enjoy outdoor activities!")
        recommendations.push("Great time for exercise and outdoor sports")
        break
      case "Moderate":
        recommendations.push("Air quality is acceptable for most people")
        recommendations.push("Sensitive individuals should consider limiting prolonged outdoor exertion")
        break
      case "Unhealthy for Sensitive Groups":
        recommendations.push("Sensitive groups should reduce outdoor activities")
        recommendations.push("Consider wearing a mask if you must go outside")
        recommendations.push("Keep windows closed and use air purifiers indoors")
        break
      case "Unhealthy":
        recommendations.push("Everyone should limit outdoor activities")
        recommendations.push("Wear N95 masks when going outside")
        recommendations.push("Avoid outdoor exercise and sports")
        break
      case "Very Unhealthy":
        recommendations.push("Avoid all outdoor activities")
        recommendations.push("Stay indoors with air purifiers running")
        recommendations.push("Seek medical attention if experiencing symptoms")
        break
      case "Hazardous":
        recommendations.push("Emergency conditions - stay indoors")
        recommendations.push("Avoid all outdoor exposure")
        recommendations.push("Seek immediate medical attention for any symptoms")
        break
    }

    // Specific pollutant recommendations
    if (data.pm25 > 35) {
      recommendations.push("High PM2.5 levels detected - use HEPA air filters")
    }
    if (data.pm10 > 150) {
      recommendations.push("High PM10 levels - avoid dusty areas")
    }
    if (data.no2 > 100) {
      recommendations.push("High NO2 levels - avoid busy roads and traffic")
    }
    if (data.o3 > 70) {
      recommendations.push("High ozone levels - limit outdoor activities during peak sun hours")
    }

    return recommendations
  }

  // AI-powered prediction (simplified model)
  static predictAQI(
    data: PollutionData,
    currentAQI: number,
  ): { nextHour: number; next6Hours: number; next24Hours: number } {
    // Simplified prediction model based on current trends and meteorological factors
    const baseVariation = Math.random() * 20 - 10 // ±10 variation
    const trendFactor = data.windSpeed ? Math.max(0.8, 1 - data.windSpeed / 20) : 1
    const humidityFactor = data.humidity ? Math.max(0.9, 1 - data.humidity / 200) : 1

    const nextHour = Math.max(0, Math.round(currentAQI + baseVariation * 0.3 * trendFactor))
    const next6Hours = Math.max(0, Math.round(currentAQI + baseVariation * 0.7 * trendFactor * humidityFactor))
    const next24Hours = Math.max(0, Math.round(currentAQI + baseVariation * 1.2 * trendFactor * humidityFactor))

    return { nextHour, next6Hours, next24Hours }
  }

  // Main classification function
  static classifyPollution(data: PollutionData): ClassificationResult {
    const aqi = this.calculateAQI(data)
    const pollutionLevel = this.getPollutionLevel(aqi)
    const healthRisk = this.getHealthRisk(aqi)
    const recommendations = this.generateRecommendations(data, aqi)
    const prediction = this.predictAQI(data, aqi)
    const dominantPollutant = this.getDominantPollutant(data)

    // Calculate confidence based on data completeness and consistency
    const dataCompleteness = Object.values(data).filter((v) => v !== undefined && v > 0).length / 6
    const confidence = Math.round(dataCompleteness * 100)

    return {
      aqi,
      pollutionLevel,
      healthRisk,
      recommendations,
      prediction,
      dominantPollutant,
      confidence,
    }
  }
}
