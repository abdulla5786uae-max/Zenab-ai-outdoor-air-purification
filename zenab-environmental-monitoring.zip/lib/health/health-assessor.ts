// Health assessment system for air quality impact evaluation
export interface HealthProfile {
  ageGroup: string
  healthConditions: string[]
  activityLevel: string
  smokingStatus: string
  pregnancyStatus?: string
  location: string
}

export interface AirQualityContext {
  aqi: number
  pm25: number
  pm10: number
  no2: number
  so2: number
  co: number
  o3: number
  pollutionLevel: string
}

export interface HealthAssessment {
  riskLevel: string
  riskScore: number
  primaryConcerns: string[]
  recommendations: string[]
  immediateActions: string[]
  longTermAdvice: string[]
  medicalConsultation: boolean
  riskFactors: {
    factor: string
    impact: string
    severity: number
  }[]
}

export class HealthAssessor {
  // Age group risk multipliers
  private static ageRiskMultipliers = {
    "0-5": 1.8,
    "6-12": 1.4,
    "13-18": 1.1,
    "19-35": 1.0,
    "36-50": 1.2,
    "51-65": 1.5,
    "65+": 2.0,
  }

  // Health condition risk factors
  private static healthConditionRisks = {
    asthma: { multiplier: 2.5, concerns: ["Respiratory distress", "Bronchospasm"] },
    copd: { multiplier: 3.0, concerns: ["Breathing difficulties", "Exacerbation"] },
    "heart-disease": { multiplier: 2.2, concerns: ["Cardiovascular stress", "Arrhythmia"] },
    diabetes: { multiplier: 1.6, concerns: ["Inflammation", "Immune response"] },
    "lung-disease": { multiplier: 2.8, concerns: ["Respiratory complications", "Infection risk"] },
    pregnancy: { multiplier: 1.8, concerns: ["Fetal development", "Preterm birth risk"] },
    "immune-compromised": { multiplier: 2.0, concerns: ["Infection susceptibility", "Recovery delays"] },
    hypertension: { multiplier: 1.7, concerns: ["Blood pressure spikes", "Cardiovascular strain"] },
    none: { multiplier: 1.0, concerns: [] },
  }

  // Activity level adjustments
  private static activityAdjustments = {
    sedentary: 0.8,
    light: 1.0,
    moderate: 1.3,
    high: 1.6,
    athlete: 2.0,
  }

  // Calculate base risk score from AQI
  private static calculateBaseRisk(aqi: number): number {
    if (aqi <= 50) return 10
    if (aqi <= 100) return 25
    if (aqi <= 150) return 50
    if (aqi <= 200) return 75
    if (aqi <= 300) return 90
    return 100
  }

  // Get risk level from score
  private static getRiskLevel(score: number): string {
    if (score <= 20) return "Low"
    if (score <= 40) return "Moderate"
    if (score <= 60) return "High"
    if (score <= 80) return "Very High"
    return "Critical"
  }

  // Generate primary health concerns
  private static generateConcerns(profile: HealthProfile, airQuality: AirQualityContext, riskScore: number): string[] {
    const concerns: string[] = []

    // AQI-based concerns
    if (airQuality.aqi > 150) {
      concerns.push("Severe respiratory irritation")
      concerns.push("Cardiovascular stress")
    } else if (airQuality.aqi > 100) {
      concerns.push("Respiratory discomfort")
      concerns.push("Eye and throat irritation")
    }

    // Pollutant-specific concerns
    if (airQuality.pm25 > 35) {
      concerns.push("Fine particulate matter exposure")
      concerns.push("Deep lung penetration risk")
    }
    if (airQuality.no2 > 100) {
      concerns.push("Nitrogen dioxide exposure")
      concerns.push("Airway inflammation")
    }
    if (airQuality.o3 > 70) {
      concerns.push("Ground-level ozone exposure")
      concerns.push("Lung function reduction")
    }

    // Health condition specific concerns
    profile.healthConditions.forEach((condition) => {
      const conditionRisk = this.healthConditionRisks[condition as keyof typeof this.healthConditionRisks]
      if (conditionRisk) {
        concerns.push(...conditionRisk.concerns)
      }
    })

    // Remove duplicates and return top concerns
    return [...new Set(concerns)].slice(0, 5)
  }

  // Generate immediate action recommendations
  private static generateImmediateActions(
    profile: HealthProfile,
    airQuality: AirQualityContext,
    riskScore: number,
  ): string[] {
    const actions: string[] = []

    if (riskScore > 80) {
      actions.push("Stay indoors immediately")
      actions.push("Close all windows and doors")
      actions.push("Use air purifiers if available")
      actions.push("Avoid all outdoor activities")
    } else if (riskScore > 60) {
      actions.push("Limit outdoor exposure")
      actions.push("Wear N95 mask when outside")
      actions.push("Avoid strenuous outdoor activities")
    } else if (riskScore > 40) {
      actions.push("Consider wearing a mask outdoors")
      actions.push("Reduce outdoor exercise intensity")
      actions.push("Monitor symptoms closely")
    } else if (riskScore > 20) {
      actions.push("Be aware of air quality conditions")
      actions.push("Consider indoor alternatives for exercise")
    }

    // Activity-specific actions
    if (profile.activityLevel === "high" || profile.activityLevel === "athlete") {
      if (riskScore > 40) {
        actions.push("Switch to indoor training")
        actions.push("Reduce exercise intensity by 50%")
      }
    }

    // Health condition specific actions
    if (profile.healthConditions.includes("asthma")) {
      actions.push("Keep rescue inhaler readily available")
      if (riskScore > 50) {
        actions.push("Consider preventive medication")
      }
    }

    if (profile.healthConditions.includes("heart-disease")) {
      actions.push("Monitor heart rate and symptoms")
      if (riskScore > 60) {
        actions.push("Avoid any physical exertion")
      }
    }

    return actions.slice(0, 6)
  }

  // Generate long-term health advice
  private static generateLongTermAdvice(
    profile: HealthProfile,
    airQuality: AirQualityContext,
    riskScore: number,
  ): string[] {
    const advice: string[] = []

    advice.push("Install HEPA air filters in your home")
    advice.push("Create a clean air room for high pollution days")
    advice.push("Monitor daily air quality forecasts")
    advice.push("Consider air quality in travel planning")

    if (riskScore > 50) {
      advice.push("Invest in a high-quality air purifier")
      advice.push("Consider relocating during high pollution seasons")
      advice.push("Develop an emergency action plan")
    }

    // Age-specific advice
    if (profile.ageGroup === "65+" || profile.ageGroup === "0-5") {
      advice.push("Schedule regular health check-ups")
      advice.push("Maintain emergency contact list")
    }

    // Health condition specific advice
    if (profile.healthConditions.length > 0) {
      advice.push("Work with healthcare provider on pollution management plan")
      advice.push("Keep medications well-stocked")
      advice.push("Join support groups for your condition")
    }

    return advice.slice(0, 6)
  }

  // Generate general recommendations
  private static generateRecommendations(
    profile: HealthProfile,
    airQuality: AirQualityContext,
    riskScore: number,
  ): string[] {
    const recommendations: string[] = []

    // Diet recommendations
    recommendations.push("Consume antioxidant-rich foods (berries, leafy greens)")
    recommendations.push("Stay well-hydrated throughout the day")
    recommendations.push("Consider vitamin C and E supplements")

    // Lifestyle recommendations
    recommendations.push("Practice breathing exercises and meditation")
    recommendations.push("Maintain good indoor air circulation")
    recommendations.push("Use natural air-purifying plants indoors")

    // Activity recommendations based on risk
    if (riskScore <= 30) {
      recommendations.push("Maintain regular outdoor exercise routine")
    } else if (riskScore <= 50) {
      recommendations.push("Exercise outdoors during early morning hours")
      recommendations.push("Choose low-traffic routes for outdoor activities")
    } else {
      recommendations.push("Focus on indoor exercise alternatives")
      recommendations.push("Use gym facilities with good air filtration")
    }

    return recommendations.slice(0, 6)
  }

  // Determine if medical consultation is needed
  private static needsMedicalConsultation(
    profile: HealthProfile,
    airQuality: AirQualityContext,
    riskScore: number,
  ): boolean {
    // High risk score
    if (riskScore > 70) return true

    // Vulnerable populations with moderate risk
    if (riskScore > 50 && (profile.ageGroup === "65+" || profile.ageGroup === "0-5")) return true

    // Health conditions with elevated risk
    if (
      riskScore > 40 &&
      (profile.healthConditions.includes("asthma") ||
        profile.healthConditions.includes("copd") ||
        profile.healthConditions.includes("heart-disease") ||
        profile.healthConditions.includes("lung-disease"))
    ) {
      return true
    }

    // Pregnancy with moderate risk
    if (riskScore > 35 && profile.healthConditions.includes("pregnancy")) return true

    return false
  }

  // Calculate risk factors breakdown
  private static calculateRiskFactors(
    profile: HealthProfile,
    airQuality: AirQualityContext,
  ): { factor: string; impact: string; severity: number }[] {
    const factors: { factor: string; impact: string; severity: number }[] = []

    // Age factor
    const ageMultiplier = this.ageRiskMultipliers[profile.ageGroup as keyof typeof this.ageRiskMultipliers] || 1.0
    if (ageMultiplier > 1.2) {
      factors.push({
        factor: "Age Group",
        impact: `${Math.round((ageMultiplier - 1) * 100)}% increased vulnerability`,
        severity: Math.min(10, Math.round(ageMultiplier * 3)),
      })
    }

    // Health conditions
    profile.healthConditions.forEach((condition) => {
      const conditionRisk = this.healthConditionRisks[condition as keyof typeof this.healthConditionRisks]
      if (conditionRisk && conditionRisk.multiplier > 1.0) {
        factors.push({
          factor: condition.replace("-", " ").replace(/\b\w/g, (l) => l.toUpperCase()),
          impact: `${Math.round((conditionRisk.multiplier - 1) * 100)}% increased risk`,
          severity: Math.min(10, Math.round(conditionRisk.multiplier * 3)),
        })
      }
    })

    // Activity level
    const activityMultiplier =
      this.activityAdjustments[profile.activityLevel as keyof typeof this.activityAdjustments] || 1.0
    if (activityMultiplier > 1.2) {
      factors.push({
        factor: "High Activity Level",
        impact: `${Math.round((activityMultiplier - 1) * 100)}% increased exposure`,
        severity: Math.min(10, Math.round(activityMultiplier * 2)),
      })
    }

    // Air quality severity
    if (airQuality.aqi > 150) {
      factors.push({
        factor: "Severe Air Pollution",
        impact: "Critical exposure levels",
        severity: 10,
      })
    } else if (airQuality.aqi > 100) {
      factors.push({
        factor: "Unhealthy Air Quality",
        impact: "Elevated exposure risk",
        severity: 7,
      })
    }

    return factors.sort((a, b) => b.severity - a.severity).slice(0, 5)
  }

  // Main assessment function
  static assessHealth(profile: HealthProfile, airQuality: AirQualityContext): HealthAssessment {
    // Calculate base risk from AQI
    let riskScore = this.calculateBaseRisk(airQuality.aqi)

    // Apply age multiplier
    const ageMultiplier = this.ageRiskMultipliers[profile.ageGroup as keyof typeof this.ageRiskMultipliers] || 1.0
    riskScore *= ageMultiplier

    // Apply health condition multipliers
    let maxHealthMultiplier = 1.0
    profile.healthConditions.forEach((condition) => {
      const conditionRisk = this.healthConditionRisks[condition as keyof typeof this.healthConditionRisks]
      if (conditionRisk) {
        maxHealthMultiplier = Math.max(maxHealthMultiplier, conditionRisk.multiplier)
      }
    })
    riskScore *= maxHealthMultiplier

    // Apply activity level adjustment
    const activityMultiplier =
      this.activityAdjustments[profile.activityLevel as keyof typeof this.activityAdjustments] || 1.0
    riskScore *= activityMultiplier

    // Cap the risk score at 100
    riskScore = Math.min(100, Math.round(riskScore))

    const riskLevel = this.getRiskLevel(riskScore)
    const primaryConcerns = this.generateConcerns(profile, airQuality, riskScore)
    const recommendations = this.generateRecommendations(profile, airQuality, riskScore)
    const immediateActions = this.generateImmediateActions(profile, airQuality, riskScore)
    const longTermAdvice = this.generateLongTermAdvice(profile, airQuality, riskScore)
    const medicalConsultation = this.needsMedicalConsultation(profile, airQuality, riskScore)
    const riskFactors = this.calculateRiskFactors(profile, airQuality)

    return {
      riskLevel,
      riskScore,
      primaryConcerns,
      recommendations,
      immediateActions,
      longTermAdvice,
      medicalConsultation,
      riskFactors,
    }
  }
}
