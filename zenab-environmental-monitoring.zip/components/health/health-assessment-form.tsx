"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Activity, User, MapPin, Heart } from "lucide-react"
import type { HealthProfile } from "@/lib/health/health-assessor"

interface HealthAssessmentFormProps {
  onSubmit: (profile: HealthProfile) => void
  isLoading?: boolean
}

export function HealthAssessmentForm({ onSubmit, isLoading }: HealthAssessmentFormProps) {
  const [profile, setProfile] = useState<HealthProfile>({
    ageGroup: "",
    healthConditions: [],
    activityLevel: "",
    smokingStatus: "",
    location: "",
  })

  const handleHealthConditionChange = (condition: string, checked: boolean) => {
    setProfile((prev) => ({
      ...prev,
      healthConditions: checked
        ? [...prev.healthConditions, condition]
        : prev.healthConditions.filter((c) => c !== condition),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(profile)
  }

  const isFormValid = profile.ageGroup && profile.activityLevel && profile.smokingStatus && profile.location

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Heart className="h-5 w-5 text-primary" />
          <span>Health Assessment Profile</span>
        </CardTitle>
        <CardDescription>
          Help us provide personalized air quality health recommendations based on your profile
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Age Group */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-primary" />
              <Label className="text-base font-medium">Age Group</Label>
            </div>
            <RadioGroup
              value={profile.ageGroup}
              onValueChange={(value) => setProfile((prev) => ({ ...prev, ageGroup: value }))}
              className="grid grid-cols-2 gap-4"
            >
              {["0-5", "6-12", "13-18", "19-35", "36-50", "51-65", "65+"].map((age) => (
                <div key={age} className="flex items-center space-x-2">
                  <RadioGroupItem value={age} id={age} />
                  <Label htmlFor={age}>{age} years</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Health Conditions */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Heart className="h-4 w-4 text-primary" />
              <Label className="text-base font-medium">Health Conditions</Label>
              <span className="text-sm text-muted-foreground">(Select all that apply)</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { id: "none", label: "None" },
                { id: "asthma", label: "Asthma" },
                { id: "copd", label: "COPD" },
                { id: "heart-disease", label: "Heart Disease" },
                { id: "diabetes", label: "Diabetes" },
                { id: "lung-disease", label: "Lung Disease" },
                { id: "pregnancy", label: "Pregnancy" },
                { id: "immune-compromised", label: "Immune Compromised" },
                { id: "hypertension", label: "Hypertension" },
              ].map((condition) => (
                <div key={condition.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={condition.id}
                    checked={profile.healthConditions.includes(condition.id)}
                    onCheckedChange={(checked) => handleHealthConditionChange(condition.id, checked as boolean)}
                  />
                  <Label htmlFor={condition.id}>{condition.label}</Label>
                </div>
              ))}
            </div>
          </div>

          {/* Activity Level */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-4 w-4 text-primary" />
              <Label className="text-base font-medium">Activity Level</Label>
            </div>
            <RadioGroup
              value={profile.activityLevel}
              onValueChange={(value) => setProfile((prev) => ({ ...prev, activityLevel: value }))}
              className="space-y-2"
            >
              {[
                { id: "sedentary", label: "Sedentary", desc: "Minimal physical activity" },
                { id: "light", label: "Light", desc: "Light exercise 1-3 days/week" },
                { id: "moderate", label: "Moderate", desc: "Moderate exercise 3-5 days/week" },
                { id: "high", label: "High", desc: "Intense exercise 6-7 days/week" },
                { id: "athlete", label: "Athlete", desc: "Professional/competitive athlete" },
              ].map((activity) => (
                <div key={activity.id} className="flex items-center space-x-2 p-3 border rounded-lg">
                  <RadioGroupItem value={activity.id} id={activity.id} />
                  <div className="flex-1">
                    <Label htmlFor={activity.id} className="font-medium">
                      {activity.label}
                    </Label>
                    <p className="text-sm text-muted-foreground">{activity.desc}</p>
                  </div>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Smoking Status */}
          <div className="space-y-4">
            <Label className="text-base font-medium">Smoking Status</Label>
            <RadioGroup
              value={profile.smokingStatus}
              onValueChange={(value) => setProfile((prev) => ({ ...prev, smokingStatus: value }))}
              className="grid grid-cols-2 gap-4"
            >
              {[
                { id: "never", label: "Never smoked" },
                { id: "former", label: "Former smoker" },
                { id: "current", label: "Current smoker" },
                { id: "passive", label: "Passive smoker" },
              ].map((smoking) => (
                <div key={smoking.id} className="flex items-center space-x-2">
                  <RadioGroupItem value={smoking.id} id={smoking.id} />
                  <Label htmlFor={smoking.id}>{smoking.label}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Location */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-primary" />
              <Label htmlFor="location" className="text-base font-medium">
                Primary Location
              </Label>
            </div>
            <Input
              id="location"
              placeholder="e.g., Delhi, Mumbai, Bangalore"
              value={profile.location}
              onChange={(e) => setProfile((prev) => ({ ...prev, location: e.target.value }))}
            />
          </div>

          {/* Submit Button */}
          <Button type="submit" className="w-full" disabled={!isFormValid || isLoading}>
            {isLoading ? "Analyzing..." : "Get Health Assessment"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
