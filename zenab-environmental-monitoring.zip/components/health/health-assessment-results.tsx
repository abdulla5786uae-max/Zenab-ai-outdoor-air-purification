"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Heart,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  Stethoscope,
  Shield,
  Activity,
  Lightbulb,
} from "lucide-react"
import type { HealthAssessment } from "@/lib/health/health-assessor"

interface HealthAssessmentResultsProps {
  assessment: HealthAssessment
  onNewAssessment: () => void
}

const getRiskColor = (risk: string) => {
  switch (risk) {
    case "Low":
      return "bg-green-100 text-green-800 border-green-200"
    case "Moderate":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "High":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "Very High":
      return "bg-red-100 text-red-800 border-red-200"
    case "Critical":
      return "bg-red-200 text-red-900 border-red-300"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

const getRiskIcon = (risk: string) => {
  switch (risk) {
    case "Low":
      return <CheckCircle className="h-5 w-5 text-green-600" />
    case "Moderate":
      return <Shield className="h-5 w-5 text-yellow-600" />
    case "High":
    case "Very High":
    case "Critical":
      return <AlertTriangle className="h-5 w-5 text-red-600" />
    default:
      return <Heart className="h-5 w-5 text-gray-600" />
  }
}

export function HealthAssessmentResults({ assessment, onNewAssessment }: HealthAssessmentResultsProps) {
  return (
    <div className="space-y-6 w-full max-w-4xl mx-auto">
      {/* Risk Overview */}
      <Card className="border-2 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Heart className="h-5 w-5 text-primary" />
            <span>Health Risk Assessment</span>
          </CardTitle>
          <CardDescription>Based on current air quality and your health profile</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {getRiskIcon(assessment.riskLevel)}
              <div>
                <Badge className={getRiskColor(assessment.riskLevel)} variant="outline">
                  {assessment.riskLevel} Risk
                </Badge>
                <p className="text-sm text-muted-foreground mt-1">Overall health risk level</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-foreground">{assessment.riskScore}</div>
              <div className="text-sm text-muted-foreground">Risk Score</div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Risk Level</span>
              <span>{assessment.riskScore}/100</span>
            </div>
            <Progress value={assessment.riskScore} className="h-3" />
          </div>

          {assessment.medicalConsultation && (
            <Alert className="border-red-200 bg-red-50">
              <Stethoscope className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <strong>Medical consultation recommended.</strong> Your risk profile suggests you should consult with a
                healthcare provider about air quality exposure.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Primary Concerns */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5 text-primary" />
            <span>Primary Health Concerns</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-3">
            {assessment.primaryConcerns.map((concern, index) => (
              <div key={index} className="flex items-center space-x-2 p-3 bg-muted/50 rounded-lg">
                <AlertTriangle className="h-4 w-4 text-orange-500 flex-shrink-0" />
                <span className="text-sm">{concern}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Risk Factors */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            <span>Risk Factor Analysis</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {assessment.riskFactors.map((factor, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{factor.factor}</span>
                  <Badge variant="outline" className="text-xs">
                    Severity: {factor.severity}/10
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{factor.impact}</p>
                <Progress value={factor.severity * 10} className="h-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Immediate Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-primary" />
            <span>Immediate Actions</span>
          </CardTitle>
          <CardDescription>Take these steps right now to protect your health</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {assessment.immediateActions.map((action, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="w-6 h-6 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-xs font-bold text-red-600">{index + 1}</span>
                </div>
                <span className="text-sm text-red-800">{action}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lightbulb className="h-5 w-5 text-primary" />
            <span>Health Recommendations</span>
          </CardTitle>
          <CardDescription>General advice to minimize health impacts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-3">
            {assessment.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start space-x-2 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <Lightbulb className="h-4 w-4 text-blue-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-blue-800">{recommendation}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Long-term Advice */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-primary" />
            <span>Long-term Health Strategy</span>
          </CardTitle>
          <CardDescription>Plan ahead for ongoing air quality management</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {assessment.longTermAdvice.map((advice, index) => (
              <div
                key={index}
                className="flex items-start space-x-3 p-3 bg-green-50 border border-green-200 rounded-lg"
              >
                <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-green-800">{advice}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Button onClick={onNewAssessment} variant="outline" className="flex-1 bg-transparent">
          Take New Assessment
        </Button>
        <Button className="flex-1">Save Assessment</Button>
        <Button variant="outline" className="flex-1 bg-transparent">
          Share Results
        </Button>
      </div>
    </div>
  )
}
