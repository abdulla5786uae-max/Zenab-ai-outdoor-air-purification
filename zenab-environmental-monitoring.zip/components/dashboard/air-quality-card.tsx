import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Wind, Thermometer, Droplets, Eye } from "lucide-react"

interface AirQualityCardProps {
  location: string
  aqi: number
  pollutionLevel: string
  pm25: number
  pm10: number
  no2: number
  timestamp: string
}

const getAQIColor = (aqi: number) => {
  if (aqi <= 50) return "bg-green-500"
  if (aqi <= 100) return "bg-yellow-500"
  if (aqi <= 150) return "bg-orange-500"
  if (aqi <= 200) return "bg-red-500"
  if (aqi <= 300) return "bg-purple-500"
  return "bg-red-800"
}

const getPollutionLevelColor = (level: string) => {
  switch (level) {
    case "Good":
      return "bg-green-100 text-green-800 border-green-200"
    case "Moderate":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "Unhealthy for Sensitive Groups":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "Unhealthy":
      return "bg-red-100 text-red-800 border-red-200"
    case "Very Unhealthy":
      return "bg-purple-100 text-purple-800 border-purple-200"
    case "Hazardous":
      return "bg-red-200 text-red-900 border-red-300"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

export function AirQualityCard({ location, aqi, pollutionLevel, pm25, pm10, no2, timestamp }: AirQualityCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">{location}</CardTitle>
          <Badge className={getPollutionLevelColor(pollutionLevel)} variant="outline">
            {pollutionLevel}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Wind className="h-5 w-5 text-primary" />
            <span className="text-sm font-medium">AQI</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${getAQIColor(aqi)}`} />
            <span className="text-2xl font-bold">{aqi}</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 text-sm">
          <div className="flex flex-col items-center space-y-1">
            <Droplets className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">PM2.5</span>
            <span className="font-semibold">{pm25}</span>
          </div>
          <div className="flex flex-col items-center space-y-1">
            <Eye className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">PM10</span>
            <span className="font-semibold">{pm10}</span>
          </div>
          <div className="flex flex-col items-center space-y-1">
            <Thermometer className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">NO₂</span>
            <span className="font-semibold">{no2}</span>
          </div>
        </div>

        <div className="text-xs text-muted-foreground text-center pt-2 border-t">
          Updated: {new Date(timestamp).toLocaleTimeString()}
        </div>
      </CardContent>
    </Card>
  )
}
