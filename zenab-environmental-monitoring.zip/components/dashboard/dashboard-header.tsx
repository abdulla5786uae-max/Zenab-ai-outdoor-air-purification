"use client"

import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { Wind, User, LogOut, Map, Activity, FileText, Brain } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import Link from "next/link"

interface DashboardHeaderProps {
  userEmail?: string
}

export function DashboardHeader({ userEmail }: DashboardHeaderProps) {
  const router = useRouter()
  const supabase = createClient()

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Wind className="h-8 w-8 text-primary" />
            <span className="text-2xl font-bold text-foreground">Zenab</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/dashboard" className="text-sm font-medium hover:text-primary transition-colors">
              Dashboard
            </Link>
            <Link
              href="/map"
              className="text-sm font-medium hover:text-primary transition-colors flex items-center space-x-1"
            >
              <Map className="h-4 w-4" />
              <span>Map</span>
            </Link>
            <Link
              href="/ai-insights"
              className="text-sm font-medium hover:text-primary transition-colors flex items-center space-x-1"
            >
              <Brain className="h-4 w-4" />
              <span>AI Insights</span>
            </Link>
            <Link
              href="/health"
              className="text-sm font-medium hover:text-primary transition-colors flex items-center space-x-1"
            >
              <Activity className="h-4 w-4" />
              <span>Health</span>
            </Link>
            <Link
              href="/reports"
              className="text-sm font-medium hover:text-primary transition-colors flex items-center space-x-1"
            >
              <FileText className="h-4 w-4" />
              <span>Reports</span>
            </Link>
          </nav>
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="flex items-center space-x-2">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">{userEmail}</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuItem asChild>
              <Link href="/profile" className="flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>Profile</span>
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleSignOut} className="flex items-center space-x-2 text-red-600">
              <LogOut className="h-4 w-4" />
              <span>Sign Out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
