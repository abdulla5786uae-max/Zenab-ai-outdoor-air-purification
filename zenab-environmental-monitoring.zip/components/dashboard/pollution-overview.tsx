import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { AlertTriangle, CheckCircle, XCircle } from "lucide-react"

interface PollutionOverviewProps {
  totalStations: number
  goodQuality: number
  moderateQuality: number
  unhealthyQuality: number
  averageAQI: number
}

export function PollutionOverview({
  totalStations,
  goodQuality,
  moderateQuality,
  unhealthyQuality,
  averageAQI,
}: PollutionOverviewProps) {
  const goodPercentage = (goodQuality / totalStations) * 100
  const moderatePercentage = (moderateQuality / totalStations) * 100
  const unhealthyPercentage = (unhealthyQuality / totalStations) * 100

  return (
    <Card>
      <CardHeader>
        <CardTitle>National Air Quality Overview</CardTitle>
        <CardDescription>Real-time monitoring across {totalStations} stations</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-center">
          <div className="text-3xl font-bold text-foreground">{averageAQI}</div>
          <div className="text-sm text-muted-foreground">National Average AQI</div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span className="text-sm">Good Quality</span>
            </div>
            <span className="text-sm font-medium">{goodQuality} stations</span>
          </div>
          <Progress value={goodPercentage} className="h-2" />

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4 text-yellow-500" />
              <span className="text-sm">Moderate Quality</span>
            </div>
            <span className="text-sm font-medium">{moderateQuality} stations</span>
          </div>
          <Progress value={moderatePercentage} className="h-2" />

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <XCircle className="h-4 w-4 text-red-500" />
              <span className="text-sm">Unhealthy Quality</span>
            </div>
            <span className="text-sm font-medium">{unhealthyQuality} stations</span>
          </div>
          <Progress value={unhealthyPercentage} className="h-2" />
        </div>
      </CardContent>
    </Card>
  )
}
