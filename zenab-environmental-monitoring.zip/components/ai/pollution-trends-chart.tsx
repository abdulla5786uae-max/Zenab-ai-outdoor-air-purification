"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, ReferenceLine } from "recharts"
import { TrendingUp, Brain } from "lucide-react"

interface TrendData {
  time: string
  actual: number
  predicted: number
  confidence: number
}

interface PollutionTrendsChartProps {
  data: TrendData[]
  pollutant: string
}

const chartConfig = {
  actual: {
    label: "Actual",
    color: "hsl(var(--chart-1))",
  },
  predicted: {
    label: "AI Predicted",
    color: "hsl(var(--chart-2))",
  },
}

export function PollutionTrendsChart({ data, pollutant }: PollutionTrendsChartProps) {
  const currentTime = new Date().getHours()

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Brain className="h-5 w-5 text-primary" />
          <span>AI Pollution Trends</span>
        </CardTitle>
        <CardDescription>Real-time vs AI predicted {pollutant} levels with confidence intervals</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig}>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <ReferenceLine
                x={`${currentTime}:00`}
                stroke="hsl(var(--muted-foreground))"
                strokeDasharray="2 2"
                label={{ value: "Now", position: "top" }}
              />
              <Line
                type="monotone"
                dataKey="actual"
                stroke="hsl(var(--chart-1))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--chart-1))", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
              <Line
                type="monotone"
                dataKey="predicted"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>

        <div className="mt-4 flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-chart-1"></div>
              <span>Actual Data</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full bg-chart-2"></div>
              <span>AI Prediction</span>
            </div>
          </div>
          <div className="flex items-center space-x-1 text-muted-foreground">
            <TrendingUp className="h-3 w-3" />
            <span>Avg. Accuracy: 87%</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
