import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Brain, TrendingUp, AlertTriangle, Lightbulb } from "lucide-react"
import type { ClassificationResult } from "@/lib/ai/pollution-classifier"

interface AIInsightsCardProps {
  insights: ClassificationResult
  location: string
}

const getRiskColor = (risk: string) => {
  switch (risk) {
    case "Low":
      return "bg-green-100 text-green-800 border-green-200"
    case "Moderate":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "High for Sensitive Groups":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "High":
      return "bg-red-100 text-red-800 border-red-200"
    case "Very High":
      return "bg-purple-100 text-purple-800 border-purple-200"
    case "Emergency":
      return "bg-red-200 text-red-900 border-red-300"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

export function AIInsightsCard({ insights, location }: AIInsightsCardProps) {
  return (
    <Card className="border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Brain className="h-5 w-5 text-primary" />
          <span>AI Pollution Analysis</span>
        </CardTitle>
        <CardDescription>Intelligent insights for {location}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Health Risk Assessment */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Health Risk Level</span>
            <Badge className={getRiskColor(insights.healthRisk)} variant="outline">
              {insights.healthRisk}
            </Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Dominant Pollutant</span>
            <span className="text-sm font-semibold text-destructive">{insights.dominantPollutant}</span>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">AI Confidence</span>
              <span className="text-sm font-semibold">{insights.confidence}%</span>
            </div>
            <Progress value={insights.confidence} className="h-2" />
          </div>
        </div>

        {/* Predictions */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">AQI Predictions</span>
          </div>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 bg-muted/50 rounded-lg">
              <div className="text-lg font-bold text-foreground">{insights.prediction.nextHour}</div>
              <div className="text-xs text-muted-foreground">Next Hour</div>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg">
              <div className="text-lg font-bold text-foreground">{insights.prediction.next6Hours}</div>
              <div className="text-xs text-muted-foreground">6 Hours</div>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg">
              <div className="text-lg font-bold text-foreground">{insights.prediction.next24Hours}</div>
              <div className="text-xs text-muted-foreground">24 Hours</div>
            </div>
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Lightbulb className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">AI Recommendations</span>
          </div>
          <div className="space-y-2">
            {insights.recommendations.slice(0, 3).map((recommendation, index) => (
              <div key={index} className="flex items-start space-x-2 p-2 bg-muted/30 rounded-lg">
                <AlertTriangle className="h-3 w-3 text-primary mt-0.5 flex-shrink-0" />
                <span className="text-xs text-muted-foreground">{recommendation}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
