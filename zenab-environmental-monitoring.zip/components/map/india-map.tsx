"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, Wind, Thermometer, Droplets, Eye } from "lucide-react"

interface StateData {
  id: string
  name: string
  aqi: number
  pollutionLevel: string
  pm25: number
  pm10: number
  no2: number
  cities: number
}

const stateData: StateData[] = [
  { id: "delhi", name: "Delhi", aqi: 168, pollutionLevel: "Unhealthy", pm25: 89.5, pm10: 145.2, no2: 45.8, cities: 3 },
  {
    id: "maharashtra",
    name: "Maharashtra",
    aqi: 95,
    pollutionLevel: "Moderate",
    pm25: 48.7,
    pm10: 82.1,
    no2: 31.2,
    cities: 6,
  },
  {
    id: "karnataka",
    name: "Karnataka",
    aqi: 76,
    pollutionLevel: "Moderate",
    pm25: 38.9,
    pm10: 65.2,
    no2: 24.1,
    cities: 3,
  },
  {
    id: "tamil-nadu",
    name: "Tamil Nadu",
    aqi: 91,
    pollutionLevel: "Moderate",
    pm25: 46.8,
    pm10: 79.5,
    no2: 29.7,
    cities: 3,
  },
  {
    id: "west-bengal",
    name: "West Bengal",
    aqi: 134,
    pollutionLevel: "Unhealthy for Sensitive Groups",
    pm25: 72.4,
    pm10: 118.9,
    no2: 41.2,
    cities: 3,
  },
  {
    id: "telangana",
    name: "Telangana",
    aqi: 92,
    pollutionLevel: "Moderate",
    pm25: 47.1,
    pm10: 80.6,
    no2: 29.4,
    cities: 3,
  },
  {
    id: "gujarat",
    name: "Gujarat",
    aqi: 112,
    pollutionLevel: "Unhealthy for Sensitive Groups",
    pm25: 58.4,
    pm10: 96.7,
    no2: 35.2,
    cities: 3,
  },
  {
    id: "rajasthan",
    name: "Rajasthan",
    aqi: 126,
    pollutionLevel: "Unhealthy for Sensitive Groups",
    pm25: 67.2,
    pm10: 109.8,
    no2: 37.9,
    cities: 3,
  },
  {
    id: "uttar-pradesh",
    name: "Uttar Pradesh",
    aqi: 156,
    pollutionLevel: "Unhealthy",
    pm25: 84.7,
    pm10: 138.9,
    no2: 46.2,
    cities: 3,
  },
]

const getStateColor = (aqi: number) => {
  if (aqi <= 50) return "#10b981" // Green
  if (aqi <= 100) return "#f59e0b" // Yellow
  if (aqi <= 150) return "#f97316" // Orange
  if (aqi <= 200) return "#ef4444" // Red
  if (aqi <= 300) return "#8b5cf6" // Purple
  return "#7f1d1d" // Dark red
}

const getPollutionLevelColor = (level: string) => {
  switch (level) {
    case "Good":
      return "bg-green-100 text-green-800 border-green-200"
    case "Moderate":
      return "bg-yellow-100 text-yellow-800 border-yellow-200"
    case "Unhealthy for Sensitive Groups":
      return "bg-orange-100 text-orange-800 border-orange-200"
    case "Unhealthy":
      return "bg-red-100 text-red-800 border-red-200"
    case "Very Unhealthy":
      return "bg-purple-100 text-purple-800 border-purple-200"
    case "Hazardous":
      return "bg-red-200 text-red-900 border-red-300"
    default:
      return "bg-gray-100 text-gray-800 border-gray-200"
  }
}

export function IndiaMap() {
  const [selectedState, setSelectedState] = useState<StateData | null>(null)
  const [hoveredState, setHoveredState] = useState<string | null>(null)

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Map Section */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-primary" />
              <span>India Air Quality Map</span>
            </CardTitle>
            <CardDescription>Click on states to view detailed air quality information</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-8 min-h-[500px] flex items-center justify-center">
              {/* Simplified India Map using CSS Grid */}
              <div className="grid grid-cols-8 grid-rows-10 gap-1 w-full max-w-md mx-auto">
                {/* Row 1 - Kashmir region */}
                <div className="col-span-2 row-span-1"></div>
                <div
                  className="col-span-2 row-span-1 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(120) }}
                  onClick={() =>
                    setSelectedState({
                      id: "jammu-kashmir",
                      name: "Jammu & Kashmir",
                      aqi: 120,
                      pollutionLevel: "Unhealthy for Sensitive Groups",
                      pm25: 65.2,
                      pm10: 102.8,
                      no2: 38.4,
                      cities: 2,
                    })
                  }
                  onMouseEnter={() => setHoveredState("jammu-kashmir")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  J&K
                </div>
                <div className="col-span-4 row-span-1"></div>

                {/* Row 2-3 - Northern states */}
                <div className="col-span-1 row-span-2"></div>
                <div
                  className="col-span-2 row-span-2 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "rajasthan")?.aqi || 126) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "rajasthan") || null)}
                  onMouseEnter={() => setHoveredState("rajasthan")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  RAJ
                </div>
                <div
                  className="col-span-1 row-span-1 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "delhi")?.aqi || 168) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "delhi") || null)}
                  onMouseEnter={() => setHoveredState("delhi")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  DEL
                </div>
                <div
                  className="col-span-2 row-span-1 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{
                    backgroundColor: getStateColor(stateData.find((s) => s.id === "uttar-pradesh")?.aqi || 156),
                  }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "uttar-pradesh") || null)}
                  onMouseEnter={() => setHoveredState("uttar-pradesh")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  UP
                </div>
                <div className="col-span-2 row-span-1"></div>

                {/* Row 4-5 - Central states */}
                <div
                  className="col-span-1 row-span-2 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "gujarat")?.aqi || 112) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "gujarat") || null)}
                  onMouseEnter={() => setHoveredState("gujarat")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  GUJ
                </div>
                <div className="col-span-2 row-span-1"></div>
                <div className="col-span-1 row-span-1"></div>
                <div
                  className="col-span-2 row-span-1 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "west-bengal")?.aqi || 134) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "west-bengal") || null)}
                  onMouseEnter={() => setHoveredState("west-bengal")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  WB
                </div>
                <div className="col-span-2 row-span-1"></div>

                {/* Row 6-7 - Western and Central states */}
                <div className="col-span-1 row-span-1"></div>
                <div
                  className="col-span-2 row-span-2 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "maharashtra")?.aqi || 95) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "maharashtra") || null)}
                  onMouseEnter={() => setHoveredState("maharashtra")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  MH
                </div>
                <div
                  className="col-span-1 row-span-1 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "telangana")?.aqi || 92) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "telangana") || null)}
                  onMouseEnter={() => setHoveredState("telangana")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  TG
                </div>
                <div className="col-span-4 row-span-1"></div>

                {/* Row 8-9 - Southern states */}
                <div className="col-span-2 row-span-1"></div>
                <div className="col-span-1 row-span-1"></div>
                <div
                  className="col-span-1 row-span-2 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "karnataka")?.aqi || 76) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "karnataka") || null)}
                  onMouseEnter={() => setHoveredState("karnataka")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  KA
                </div>
                <div
                  className="col-span-2 row-span-2 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(stateData.find((s) => s.id === "tamil-nadu")?.aqi || 91) }}
                  onClick={() => setSelectedState(stateData.find((s) => s.id === "tamil-nadu") || null)}
                  onMouseEnter={() => setHoveredState("tamil-nadu")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  TN
                </div>
                <div className="col-span-2 row-span-1"></div>

                {/* Row 10 - Kerala */}
                <div className="col-span-3 row-span-1"></div>
                <div
                  className="col-span-1 row-span-1 rounded cursor-pointer transition-all duration-200 flex items-center justify-center text-xs font-semibold text-white shadow-md hover:shadow-lg transform hover:scale-105"
                  style={{ backgroundColor: getStateColor(65) }}
                  onClick={() =>
                    setSelectedState({
                      id: "kerala",
                      name: "Kerala",
                      aqi: 65,
                      pollutionLevel: "Moderate",
                      pm25: 32.8,
                      pm10: 55.4,
                      no2: 20.1,
                      cities: 3,
                    })
                  }
                  onMouseEnter={() => setHoveredState("kerala")}
                  onMouseLeave={() => setHoveredState(null)}
                >
                  KL
                </div>
                <div className="col-span-4 row-span-1"></div>
              </div>

              {/* Hover tooltip */}
              {hoveredState && (
                <div className="absolute top-4 right-4 bg-background border rounded-lg p-3 shadow-lg">
                  <p className="text-sm font-medium">Click to view details</p>
                </div>
              )}
            </div>

            {/* Legend */}
            <div className="mt-6 p-4 bg-muted/50 rounded-lg">
              <h4 className="text-sm font-semibold mb-3">Air Quality Index Legend</h4>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-xs">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#10b981" }}></div>
                  <span>Good (0-50)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#f59e0b" }}></div>
                  <span>Moderate (51-100)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#f97316" }}></div>
                  <span>Unhealthy for Sensitive (101-150)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#ef4444" }}></div>
                  <span>Unhealthy (151-200)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#8b5cf6" }}></div>
                  <span>Very Unhealthy (201-300)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: "#7f1d1d" }}></div>
                  <span>Hazardous (300+)</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* State Details Panel */}
      <div className="lg:col-span-1">
        <Card className="sticky top-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Wind className="h-5 w-5 text-primary" />
              <span>State Details</span>
            </CardTitle>
            <CardDescription>
              {selectedState ? `Air quality information for ${selectedState.name}` : "Click on a state to view details"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedState ? (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-foreground">{selectedState.name}</h3>
                  <Badge className={getPollutionLevelColor(selectedState.pollutionLevel)} variant="outline">
                    {selectedState.pollutionLevel}
                  </Badge>
                </div>

                <div className="text-center">
                  <div className="text-4xl font-bold text-foreground mb-2">{selectedState.aqi}</div>
                  <div className="text-sm text-muted-foreground">Air Quality Index</div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Droplets className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">PM2.5</span>
                    </div>
                    <span className="font-semibold">{selectedState.pm25} μg/m³</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Eye className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">PM10</span>
                    </div>
                    <span className="font-semibold">{selectedState.pm10} μg/m³</span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Thermometer className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">NO₂</span>
                    </div>
                    <span className="font-semibold">{selectedState.no2} μg/m³</span>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Monitoring Stations</span>
                    <span className="font-medium">{selectedState.cities} active</span>
                  </div>
                </div>

                <Button className="w-full bg-transparent" variant="outline">
                  View Detailed Report
                </Button>
              </div>
            ) : (
              <div className="text-center py-12">
                <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">
                  Select a state on the map to view detailed air quality information
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
