-- Insert sample air quality data for major Indian cities
INSERT INTO public.air_quality_data (location, state, city, latitude, longitude, aqi, pm25, pm10, no2, so2, co, o3, pollution_level) VALUES
-- Delhi
('Connaught Place', 'Delhi', 'New Delhi', 28.6315, 77.2167, 168, 89.5, 145.2, 45.8, 12.3, 1.2, 78.9, 'Unhealthy'),
('Anand Vihar', 'Delhi', 'New Delhi', 28.6469, 77.3152, 201, 125.8, 189.4, 52.1, 18.7, 1.8, 85.2, 'Very Unhealthy'),
('Dwarka', 'Delhi', 'New Delhi', 28.5921, 77.0460, 142, 78.3, 128.6, 38.9, 9.8, 1.1, 65.4, 'Unhealthy for Sensitive Groups'),

-- Mumbai
('Bandra Kurla Complex', 'Maharashtra', 'Mumbai', 19.0596, 72.8656, 89, 45.2, 78.9, 28.4, 8.1, 0.9, 52.3, 'Moderate'),
('Worli', 'Maharashtra', 'Mumbai', 19.0176, 72.8162, 95, 48.7, 82.1, 31.2, 9.3, 1.0, 55.8, 'Moderate'),
('Andheri', 'Maharashtra', 'Mumbai', 19.1136, 72.8697, 102, 52.8, 89.4, 34.6, 10.7, 1.1, 58.9, 'Unhealthy for Sensitive Groups'),

-- Bangalore
('Silk Board', 'Karnataka', 'Bangalore', 12.9176, 77.6256, 76, 38.9, 65.2, 24.1, 6.8, 0.8, 45.3, 'Moderate'),
('Whitefield', 'Karnataka', 'Bangalore', 12.9698, 77.7500, 68, 34.2, 58.7, 21.8, 5.9, 0.7, 41.2, 'Moderate'),
('BTM Layout', 'Karnataka', 'Bangalore', 12.9165, 77.6101, 82, 41.5, 71.3, 26.4, 7.2, 0.9, 48.7, 'Moderate'),

-- Chennai
('T. Nagar', 'Tamil Nadu', 'Chennai', 13.0418, 80.2341, 91, 46.8, 79.5, 29.7, 8.4, 0.9, 53.1, 'Moderate'),
('Adyar', 'Tamil Nadu', 'Chennai', 13.0067, 80.2206, 87, 44.1, 75.8, 27.9, 7.8, 0.8, 50.6, 'Moderate'),
('Velachery', 'Tamil Nadu', 'Chennai', 12.9815, 80.2209, 94, 47.9, 81.2, 30.8, 8.9, 1.0, 54.7, 'Moderate'),

-- Kolkata
('Jadavpur', 'West Bengal', 'Kolkata', 22.4998, 88.3712, 134, 72.4, 118.9, 41.2, 11.8, 1.3, 62.7, 'Unhealthy for Sensitive Groups'),
('Salt Lake', 'West Bengal', 'Kolkata', 22.5958, 88.4497, 128, 68.9, 112.4, 38.7, 10.9, 1.2, 59.8, 'Unhealthy for Sensitive Groups'),
('Park Street', 'West Bengal', 'Kolkata', 22.5549, 88.3516, 145, 78.6, 128.7, 43.9, 12.7, 1.4, 67.2, 'Unhealthy for Sensitive Groups'),

-- Hyderabad
('Gachibowli', 'Telangana', 'Hyderabad', 17.4399, 78.3489, 85, 43.7, 74.2, 26.8, 7.5, 0.8, 49.3, 'Moderate'),
('Jubilee Hills', 'Telangana', 'Hyderabad', 17.4239, 78.4738, 92, 47.1, 80.6, 29.4, 8.2, 0.9, 52.8, 'Moderate'),
('Secunderabad', 'Telangana', 'Hyderabad', 17.5040, 78.5030, 98, 50.2, 85.9, 32.1, 9.1, 1.0, 56.4, 'Moderate'),

-- Pune
('Shivaji Nagar', 'Maharashtra', 'Pune', 18.5308, 73.8475, 79, 40.3, 68.7, 25.2, 7.0, 0.8, 46.8, 'Moderate'),
('Kothrud', 'Maharashtra', 'Pune', 18.5074, 73.8077, 73, 37.1, 63.4, 23.6, 6.4, 0.7, 43.2, 'Moderate'),
('Wakad', 'Maharashtra', 'Pune', 18.5975, 73.7898, 81, 41.8, 70.9, 26.7, 7.3, 0.8, 48.1, 'Moderate'),

-- Ahmedabad
('Navrangpura', 'Gujarat', 'Ahmedabad', 23.0395, 72.5566, 112, 58.4, 96.7, 35.2, 10.1, 1.1, 61.3, 'Unhealthy for Sensitive Groups'),
('Satellite', 'Gujarat', 'Ahmedabad', 23.0258, 72.5873, 108, 56.1, 92.8, 33.7, 9.6, 1.0, 58.9, 'Unhealthy for Sensitive Groups'),
('Maninagar', 'Gujarat', 'Ahmedabad', 22.9965, 72.5992, 115, 59.7, 99.2, 36.4, 10.4, 1.2, 63.1, 'Unhealthy for Sensitive Groups'),

-- Jaipur
('C-Scheme', 'Rajasthan', 'Jaipur', 26.9124, 75.7873, 126, 67.2, 109.8, 37.9, 10.6, 1.2, 58.4, 'Unhealthy for Sensitive Groups'),
('Malviya Nagar', 'Rajasthan', 'Jaipur', 26.8467, 75.8648, 132, 70.8, 115.6, 40.1, 11.2, 1.3, 61.7, 'Unhealthy for Sensitive Groups'),
('Vaishali Nagar', 'Rajasthan', 'Jaipur', 26.9157, 75.7272, 119, 63.4, 104.2, 35.8, 9.9, 1.1, 55.2, 'Unhealthy for Sensitive Groups'),

-- Lucknow
('Gomti Nagar', 'Uttar Pradesh', 'Lucknow', 26.8467, 81.0060, 156, 84.7, 138.9, 46.2, 13.1, 1.5, 72.3, 'Unhealthy'),
('Hazratganj', 'Uttar Pradesh', 'Lucknow', 26.8467, 80.9462, 162, 88.1, 144.6, 48.7, 13.8, 1.6, 75.9, 'Unhealthy'),
('Alambagh', 'Uttar Pradesh', 'Lucknow', 26.8206, 80.9042, 149, 81.3, 133.7, 44.6, 12.4, 1.4, 69.1, 'Unhealthy for Sensitive Groups');

-- Update timestamps to be more recent and varied
UPDATE public.air_quality_data 
SET timestamp = NOW() - (RANDOM() * INTERVAL '2 hours'),
    created_at = NOW() - (RANDOM() * INTERVAL '2 hours');
